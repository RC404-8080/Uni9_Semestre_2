# ProjetoUninove JAVA

### Projeto desenvolvido em um grupo 6 alunos para simular um aplicativo de jogos.<br><br>
A aplicação possui simulação de compra da moeda virtual da plataforma necessaria para comprar os jogos (essas compras sâo salvas em um banco de dados). Caso tenha feito uma conta, é possivel, jogar 2 jogos, recuperar sua senha clicando no link de esqueci senha,
(passando as informações corretas você ira receber e-mail com codigo para conseguir trocar a senha); há outras funcionalidades também para ser vistas.

Espero que gostem;

se não obtiver sucesso para executar o programa, aqui esta o link de aprensetação do projeto https://www.youtube.com/watch?v=56gHB7EZmo0&list=LL&index=66<br><br>

Envolvidos:<br><br>
Arthur Sampaio Fernandes<br>
Geovanio de Assis dos Santos<br>
Gustavo Henrique Schneider<br>
Kauan Dias Clementino<br>
Renan Carlos da Silva Porto<br>
Ryan da Silva Ribeiro<br>
Willian Yu Chen<br>
